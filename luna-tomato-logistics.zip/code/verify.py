"""Kontroll i pavarur: verifikon zgjidhjen (0/1 per rresht) dhe llogarit peshen.
Perdorim: python verify.py INSTANCE.txt SOLUTION.txt
INSTANCE.txt = skedari origjinal i ESA-s (rreshta: e l d w)."""
import sys
import numpy as np
a = np.loadtxt(sys.argv[1]); x = np.loadtxt(sys.argv[2]).astype(int)
assert len(a) == len(x), "gjatesi e gabuar"
i = np.flatnonzero(x)
ok = all(len(set(a[i, k])) == len(i) for k in range(3))
print("e vlefshme:", ok, "| transferime:", len(i), "| pesha:", round(a[i, 3].sum(), 3))
