"""Large Neighbourhood Search for weighted 3D matching.
Repeatedly frees a random subset of selected triples and re-solves the freed region
exactly with a MILP (HiGHS). Accept only if the weight improves.

usage: python -I lns.py INSTANCE.txt INIT.txt OUT.txt SEED MINUTES FRAC_LO FRAC_HI SUB_TL
"""
import sys, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import csr_matrix

inst, init, out = sys.argv[1], sys.argv[2], sys.argv[3]
seed, minutes = int(sys.argv[4]), float(sys.argv[5])
flo, fhi, sub_tl = float(sys.argv[6]), float(sys.argv[7]), float(sys.argv[8])
rng = np.random.default_rng(seed)

a = np.loadtxt(inst)
E, L, D = a[:, 0].astype(int), a[:, 1].astype(int), a[:, 2].astype(int)
W = a[:, 3]
n = len(W)
sel = np.loadtxt(init).astype(bool)
assert len(sel) == n


def valid(s):
    i = np.flatnonzero(s)
    return (len(set(E[i])) == len(i) and len(set(L[i])) == len(i)
            and len(set(D[i])) == len(i))


assert valid(sel)
best = W[sel].sum()
print("start", round(best, 3), flush=True)
t_end = time.time() + minutes * 60
it = 0
while time.time() < t_end:
    it += 1
    frac = rng.uniform(flo, fhi)
    chosen = np.flatnonzero(sel)
    freed = rng.choice(chosen, size=max(1, int(frac * len(chosen))), replace=False)
    fixed = sel.copy()
    fixed[freed] = False
    uE = np.zeros(E.max() + 1, bool); uL = np.zeros(L.max() + 1, bool); uD = np.zeros(D.max() + 1, bool)
    uE[E[fixed]] = True; uL[L[fixed]] = True; uD[D[fixed]] = True
    cand = np.flatnonzero(~uE[E] & ~uL[L] & ~uD[D])
    cur_free = W[sel & ~fixed].sum()
    # constraints over candidate nodes
    rows, off = [], 0
    for arr in (E, L, D):
        u, inv = np.unique(arr[cand], return_inverse=True)
        rows.append(inv + off); off += len(u)
    A = csr_matrix((np.ones(3 * len(cand)), (np.concatenate(rows), np.tile(np.arange(len(cand)), 3))),
                   shape=(off, len(cand)))
    t0 = time.time()
    res = milp(c=-W[cand], constraints=LinearConstraint(A, -np.inf, 1.0),
               integrality=np.ones(len(cand)), bounds=Bounds(0, 1),
               options={"time_limit": sub_tl, "mip_rel_gap": 1e-7})
    if res.x is None:
        continue
    x = np.round(res.x).astype(bool)
    new_free = W[cand][x].sum()
    if new_free > cur_free + 1e-9:
        new = fixed.copy()
        new[cand[x]] = True
        if valid(new):
            sel = new
            best = W[sel].sum()
            np.savetxt(out, sel.astype(int), fmt="%d")
            print(f"it {it} frac {frac:.2f} cand {len(cand)} +{new_free - cur_free:.3f} -> {best:.3f} "
                  f"({time.time() - t0:.1f}s, st {res.status})", flush=True)
    elif it % 10 == 0:
        print(f"it {it} no gain (cand {len(cand)}, {time.time() - t0:.1f}s, st {res.status}) best {best:.3f}", flush=True)
np.savetxt(out, sel.astype(int), fmt="%d")
print("final", round(best, 3), flush=True)
