// Simulated annealing for weighted 3-dimensional matching.
// usage: sa3dm INSTANCE.txt OUT.txt SEED TOTAL_MOVES T0 T1 [INIT.txt]
// Output: one 0/1 per line (input order). Prints best weight.
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

static uint64_t s[2];
static inline uint64_t rotl(uint64_t x, int k) { return (x << k) | (x >> (64 - k)); }
static inline uint64_t nxt(void) {
    uint64_t s0 = s[0], s1 = s[1], r = s0 + s1;
    s1 ^= s0; s[0] = rotl(s0, 55) ^ s1 ^ (s1 << 14); s[1] = rotl(s1, 36);
    return r;
}
static inline double rnd(void) { return (nxt() >> 11) * (1.0 / 9007199254740992.0); }

int main(int argc, char **argv) {
    if (argc < 7) { fprintf(stderr, "bad args\n"); return 1; }
    FILE *f = fopen(argv[1], "r");
    int cap = 1 << 20, n = 0;
    int *E = malloc(cap * sizeof(int)), *L = malloc(cap * sizeof(int)), *D = malloc(cap * sizeof(int));
    double *W = malloc(cap * sizeof(double));
    int me = 0, ml = 0, md = 0;
    while (fscanf(f, "%d %d %d %lf", &E[n], &L[n], &D[n], &W[n]) == 4) {
        if (E[n] > me) me = E[n]; if (L[n] > ml) ml = L[n]; if (D[n] > md) md = D[n];
        n++;
    }
    fclose(f);
    uint64_t seed = strtoull(argv[3], 0, 10);
    s[0] = seed * 0x9E3779B97F4A7C15ULL + 1; s[1] = seed ^ 0xD1B54A32D192ED03ULL;
    for (int i = 0; i < 20; i++) nxt();
    double moves = atof(argv[4]), T0 = atof(argv[5]), T1 = atof(argv[6]);
    int *oE = malloc((me + 1) * sizeof(int)), *oL = malloc((ml + 1) * sizeof(int)), *oD = malloc((md + 1) * sizeof(int));
    for (int i = 0; i <= me; i++) oE[i] = -1;
    for (int i = 0; i <= ml; i++) oL[i] = -1;
    for (int i = 0; i <= md; i++) oD[i] = -1;
    char *sel = calloc(n, 1), *best = calloc(n, 1);
    double cur = 0, bestv = 0;
    if (argc > 7) {
        FILE *g = fopen(argv[7], "r"); int v;
        for (int i = 0; i < n && fscanf(g, "%d", &v) == 1; i++)
            if (v && oE[E[i]] < 0 && oL[L[i]] < 0 && oD[D[i]] < 0) {
                sel[i] = 1; oE[E[i]] = oL[L[i]] = oD[D[i]] = i; cur += W[i];
            }
        fclose(g);
        memcpy(best, sel, n); bestv = cur;
    }
    long long N = (long long)moves;
    double lt0 = log(T0), lt1 = log(T1);
    double T = T0;
    for (long long it = 0; it < N; it++) {
        if ((it & 0xFFFF) == 0) T = exp(lt0 + (lt1 - lt0) * ((double)it / N));
        int t = nxt() % n;
        if (sel[t]) continue;
        int c1 = oE[E[t]], c2 = oL[L[t]], c3 = oD[D[t]];
        double loss = 0;
        if (c1 >= 0) loss += W[c1];
        if (c2 >= 0 && c2 != c1) loss += W[c2];
        if (c3 >= 0 && c3 != c1 && c3 != c2) loss += W[c3];
        double delta = W[t] - loss;
        if (delta >= 0 || rnd() < exp(delta / T)) {
            if (c1 >= 0) { sel[c1] = 0; oE[E[c1]] = oL[L[c1]] = oD[D[c1]] = -1; }
            if (c2 >= 0 && sel[c2]) { sel[c2] = 0; oE[E[c2]] = oL[L[c2]] = oD[D[c2]] = -1; }
            if (c3 >= 0 && sel[c3]) { sel[c3] = 0; oE[E[c3]] = oL[L[c3]] = oD[D[c3]] = -1; }
            sel[t] = 1; oE[E[t]] = oL[L[t]] = oD[D[t]] = t;
            cur += delta;
            if (cur > bestv + 1e-9) { bestv = cur; memcpy(best, sel, n); }
        }
    }
    // recompute & verify
    double tot = 0; int cnt = 0;
    int *ce = calloc(me + 1, sizeof(int)), *cl = calloc(ml + 1, sizeof(int)), *cd = calloc(md + 1, sizeof(int));
    int ok = 1;
    for (int i = 0; i < n; i++) if (best[i]) {
        tot += W[i]; cnt++;
        if (ce[E[i]]++ || cl[L[i]]++ || cd[D[i]]++) ok = 0;
    }
    printf("best %.3f (recomputed %.3f) selected %d valid %d\n", bestv, tot, cnt, ok);
    FILE *o = fopen(argv[2], "w");
    for (int i = 0; i < n; i++) fprintf(o, "%d\n", best[i]);
    fclose(o);
    return ok ? 0 : 2;
}
