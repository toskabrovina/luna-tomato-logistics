"""LP relaxation of weighted 3D matching with interior point -> upper bound + fractional guidance.
usage: python -I lp_bound.py INSTANCE.txt OUT.npy
"""
import sys, time
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import csr_matrix

a = np.loadtxt(sys.argv[1])
e, l, d = a[:, 0].astype(int), a[:, 1].astype(int), a[:, 2].astype(int)
w = a[:, 3]
n = len(w)
rows, off = [], 0
for arr in (e, l, d):
    u, inv = np.unique(arr, return_inverse=True)
    rows.append(inv + off)
    off += len(u)
rows = np.concatenate(rows)
cols = np.tile(np.arange(n), 3)
A = csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(off, n))
t = time.time()
r = linprog(-w, A_ub=A, b_ub=np.ones(off), bounds=(0, 1), method="highs-ipm",
            options={"time_limit": 600, "disp": False})
print(r.status, r.message, "LP upper bound", -r.fun, "time", time.time() - t)
x = r.x
print("integral frac:", np.mean(np.abs(x - np.round(x)) < 1e-6), "ones:", int((x > 0.999).sum()))
np.save(sys.argv[2], x)
