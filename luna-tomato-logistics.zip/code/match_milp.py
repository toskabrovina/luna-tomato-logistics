"""Weighted 3D matching (Luna Tomato Logistics, Beginner problems) via MILP (HiGHS).

usage: python -I match_milp.py INSTANCE.txt OUT.json PROBLEM_ID TIME_LIMIT_S
"""
import sys, json, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import csr_matrix


def load(path):
    a = np.loadtxt(path)
    e = a[:, 0].astype(int)
    l = a[:, 1].astype(int)
    d = a[:, 2].astype(int)
    w = a[:, 3]
    return e, l, d, w


def build(e, l, d, w):
    n = len(w)
    rows, cols = [], []
    off = 0
    for arr in (e, l, d):
        u, inv = np.unique(arr, return_inverse=True)
        rows.append(inv + off)
        cols.append(np.arange(n))
        off += len(u)
    rows = np.concatenate(rows)
    cols = np.concatenate(cols)
    A = csr_matrix((np.ones(len(rows)), (rows, cols)), shape=(off, n))
    return A


def check(e, l, d, w, x):
    idx = np.flatnonzero(x > 0.5)
    ok = (len(set(e[idx])) == len(idx) and len(set(l[idx])) == len(idx)
          and len(set(d[idx])) == len(idx))
    return ok, float(w[idx].sum()), len(idx)


def main():
    path, out, prob, tl = sys.argv[1], sys.argv[2], sys.argv[3], float(sys.argv[4])
    e, l, d, w = load(path)
    A = build(e, l, d, w)
    t = time.time()
    res = milp(c=-w, constraints=LinearConstraint(A, -np.inf, 1.0),
               integrality=np.ones(len(w)), bounds=Bounds(0, 1),
               options={"time_limit": tl, "disp": True, "mip_rel_gap": 1e-9})
    print("status", res.status, res.message, "time", time.time() - t)
    x = np.round(res.x).astype(int)
    ok, val, k = check(e, l, d, w, x)
    print("valid", ok, "weight", val, "selected", k, "dual bound",
          getattr(res, "mip_dual_bound", None))
    assert ok
    json.dump([{"decisionVector": x.tolist(), "problem": prob,
                "challenge": "spoc-4-luna-tomato-logistics"}], open(out, "w"))


main()
