# Luna Tomato Logistics: problemet Matching I dhe II (SpOC 4)

Punim fakulteti mbi optimizimin kombinatorik. Zgjidhim problemet "Beginner" të sfidës
*Luna Tomato Logistics* të konkursit **SpOC 4** (ESA Advanced Concepts Team, 2026) dhe
krahasojmë rezultatin me tabelën publike të renditjes në platformën Optimise.

> Zhvilluar me ndihmën e Claude (Anthropic) për kodin dhe eksperimentet.
> (Hiq ose ndrysho këtë rresht sipas rregullave të lëndës.)

## 1. Problemi

Janë dhënë tri bashkësi nyjesh: orbita Toke (E), orbita Hëne (L) dhe destinacione (D).
Një *transferim* është një treshe `(e, l, d)` me një peshë `w` (masa e domateve).
Duhet zgjedhur një nënbashkësi transferimesh ashtu që **asnjë E, L apo D të mos përdoret dy herë**,
duke **maksimizuar peshën totale**. Ky është *weighted 3-dimensional matching*, problem NP-i vështirë.

| Instanca | Nyje për bashkësi | Transferime (variabla) |
|---|---|---|
| Matching I | 5,000 | 25,000 |
| Matching II | 10,000 | 92,103 |

Të dhënat janë të ESA-s dhe nuk përfshihen këtu. Shkarkoji nga repo zyrtare
<https://github.com/esa/SpOC4> (folderi `Challenge 1 Luna Tomato Logistics`, skedarët
`matching-i.txt` dhe `matching-ii.txt`).

## 2. Metodat

1. **MILP i drejtpërdrejtë** (`code/match_milp.py`, HiGHS nga SciPy). Pas 4 minutash dha vetëm
   **24,869** në Matching I (relaksimi LP shumë i ngadaltë me simplex). Shërbeu si bazë krahasimi.
2. **Relaksim LP me pika të brendshme** (`code/lp_bound.py`). Zgjidhet në ~6 sekonda dhe jep
   **kufi të sipërm**: 34,120.5 (Matching I) dhe 75,360.0 (Matching II). Zgjidhja LP nuk është
   e plotë (rreth 55% e variablave në 0 ose 1), ndaj kufiri nuk është i arritshëm.
3. **Simulated annealing** në C (`code/sa3dm.c`). Lëvizja: zgjidhet një treshe e rastit,
   futet në zgjidhje dhe hiqen treshet që e bllokojnë; pranohet sipas kriterit Metropolis.
   Ftohje eksponenciale, ~2·10⁹ lëvizje për ~1 minutë. Rezultat Matching I: **33,368**.
4. **Large Neighbourhood Search (LNS)** (`code/lns.py`). Lihet e lirë një pjesë e rastit
   (30-90%) e transferimeve të zgjedhura dhe zona e liruar zgjidhet *saktësisht* me MILP;
   pranohet vetëm nëse pesha rritet. Ngjiti Matching I në **33,458** dhe Matching II në **72,505**.
5. **Eliminimi me kosto të reduktuar** nga LP u provua, por nuk eliminoi asnjë variabël
   (hendeku LP ~664 është shumë më i madh se peshat individuale ≤ 10).

## 3. Rezultatet

| Instanca | Annealing | + LNS (final) | Kufiri LP | Hendeku ndaj LP |
|---|---|---|---|---|
| Matching I | 33,368 | **33,458.089** | 34,120.5 | 1.9% |
| Matching II | 72,284 | **72,505.224** | 75,360.0 | 3.8% |

Zgjidhjet janë në `solutions/` (një 0/1 për rresht në rendin e instancës, plus skedarë JSON në
formatin e Optimise). Kontroll i pavarur: `python code/verify.py matching-i.txt solutions/matching-i_solution.txt`.

## 4. Krahasim me tabelën e renditjes (Optimise, Matching I)

Tabela e renditjes e parë më 23.11.2026 (vetëm 5 të parët të njohur):

| Vendi | Pesha |
|---|---|
| 1 | 33,567.564 |
| 2 | 33,564.062 |
| 3 | 33,563.803 |
| 4 | 33,550.145 |
| 5 | 33,548.085 |
| **Ky punim** (nuk është dorëzuar) | **33,458.089** |

Zgjidhja jonë është **0.31% nën vendin e tretë** dhe do të vinte rreth vendit 6 ose më poshtë.
Peshat e krerëve janë shumë afër njëra-tjetrës, që sugjeron se optimumi real është rreth 33,570,
pra afër dhe nën kufirin LP. Për Matching II nuk kemi të dhëna renditjeje.
Konkursi zyrtar u mbyll më 30.06.2026, ndaj këto rezultate nuk kanë të bëjnë me çmimet.

## 5. Kufizime dhe punë e mëtejshme

- Problemi **Trajectory Matching** (Advanced, 400 transfere me trajektore në modelin bicircular)
  **nuk është zgjidhur**: kodi validues zyrtar (UDP) nuk ishte i disponueshëm, ndaj konventat
  (kuptimi i T1, T2, sistemi i koordinatave) nuk ishin të qarta.
- Për të mbyllur hendekun në Matching I do të duhej një metodë më e fortë: kërkim tabu, ose
  LNS me zona të strukturuara (jo të rastit), ose zgjidhës komercial si Gurobi/CPLEX me kohë të gjatë.

## 6. Përdorimi

```bash
gcc -O3 -march=native -o code/sa3dm code/sa3dm.c -lm
./code/sa3dm matching-i.txt out.txt SEED 2e9 1.0 0.1          # annealing
python code/lns.py matching-i.txt out.txt lns_out.txt SEED MINUTA 0.5 0.85 60   # LNS
python code/lp_bound.py matching-i.txt lp.npy                  # kufiri LP
```

Kërkon Python 3 me `numpy` dhe `scipy`.
