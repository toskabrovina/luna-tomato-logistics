"""Solution merging: exact MILP over the UNION of triples used by several good solutions.
usage: python -I merge.py INSTANCE.txt OUT.txt TIME_LIMIT BEST.txt VARIANT1.txt VARIANT2.txt ...
Writes OUT.txt only if strictly better than BEST.txt. Prints new weight.
"""
import sys, time
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import csr_matrix

inst, out, tl, best_f = sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4]
files = [best_f] + sys.argv[5:]
a = np.loadtxt(inst)
E, L, D = a[:, 0].astype(int), a[:, 1].astype(int), a[:, 2].astype(int)
W = a[:, 3]
sols = [np.loadtxt(f).astype(bool) for f in files]
best = sols[0]
bw = W[best].sum()
union = np.zeros(len(W), bool)
for s in sols:
    union |= s
cand = np.flatnonzero(union)
rows, off = [], 0
for arr in (E, L, D):
    u, inv = np.unique(arr[cand], return_inverse=True)
    rows.append(inv + off); off += len(u)
A = csr_matrix((np.ones(3 * len(cand)), (np.concatenate(rows), np.tile(np.arange(len(cand)), 3))),
               shape=(off, len(cand)))
t = time.time()
res = milp(c=-W[cand], constraints=LinearConstraint(A, -np.inf, 1.0),
           integrality=np.ones(len(cand)), bounds=Bounds(0, 1),
           options={"time_limit": tl, "mip_rel_gap": 1e-9})
if res.x is None:
    print("no solution", bw); sys.exit(0)
x = np.round(res.x).astype(bool)
new = np.zeros(len(W), bool); new[cand[x]] = True
i = np.flatnonzero(new)
ok = len(set(E[i])) == len(i) and len(set(L[i])) == len(i) and len(set(D[i])) == len(i)
nw = W[new].sum()
print(f"union {len(cand)} status {res.status} time {time.time()-t:.1f}s  best {bw:.3f} -> merged {nw:.3f} valid {ok}")
if ok and nw > bw + 1e-9:
    np.savetxt(out, new.astype(int), fmt="%d")
    print("saved", out)
